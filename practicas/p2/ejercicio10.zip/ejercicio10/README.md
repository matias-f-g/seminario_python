# Seminario de Python 2026
## Práctica 2
### Actividad 10: Competencia de cocina

---

## REQUISITOS

* Tener instalado **Python 3.10 o superior** (la cátedra recomienda la versión 3.13.12)
* Tener **Jupyter Notebook** (podés instalarlo con el siguiente comando: `pip install notebook`)

---

## ESTRUCTURA DE LOS ARCHIVOS

```text
/actividad10
    /README.md
    /notebook
        /ejercicio_10.ipynb    <- la parte ejecutable
    /src
        /ej_10.py              <- el archivo de Python completo
```

---

## ¿CÓMO SE USA?

1. Abrir una terminal en la carpeta raiz del proyecto.
2. Ejecutar: `jupyter notebook`
3. En el navegador, entrar a la carpeta `notebook/`.
4. Abrir `ejercicio_10.ipynb`.
5. En el menu superior, ir a **Run -> Run All Cells**.

---

## POSIBLE ERROR

Si arriba a la derecha del notebook dice **"Kernel Unknown"**, ejecutar en la terminal:

```bash
pip install ipykernel
python -m ipykernel install --user
```

Luego ir a **Kernel -> Change Kernel** y seleccionar **Python 3** (o lo más parecido que encuentres).
