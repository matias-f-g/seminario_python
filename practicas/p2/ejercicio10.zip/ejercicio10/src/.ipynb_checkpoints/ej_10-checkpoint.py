"""Simule una competencia de cocina donde 5 participantes son evaluados por 3
jueces en cada ronda. Cada juez otorga un puntaje del 1 al 10. El puntaje de la
ronda es la suma de los tres jueces.
"""

# IMPORTANTE: una precondición clave es que hay un, y solo un, ganador por ronda;
# asimismo, uno, y solo uno, gana la copmpetencia

rounds = [
          {'theme': 'Entrada', 'scores': {'Valentina': {'judge_1': 8, 'judge_2': 7, 'judge_3': 9},
                                          'Mateo': {'judge_1': 7, 'judge_2': 8, 'judge_3': 7},
                                          'Camila': {'judge_1': 9, 'judge_2': 9, 'judge_3': 8},
                                          'Santiago': {'judge_1': 6, 'judge_2': 7, 'judge_3': 6},
                                          'Lucía': {'judge_1': 8, 'judge_2': 8, 'judge_3': 8}
                                          }
          },
          {'theme': 'Plato principal', 'scores': {'Valentina': {'judge_1': 9, 'judge_2': 9, 'judge_3': 8},
                                                  'Mateo': {'judge_1': 8, 'judge_2': 7, 'judge_3': 9},
                                                  'Camila': {'judge_1': 7, 'judge_2': 6, 'judge_3': 7},
                                                  'Santiago': {'judge_1': 9, 'judge_2': 8, 'judge_3': 8},
                                                  'Lucía': {'judge_1': 7, 'judge_2': 8, 'judge_3': 7}
                                                  }
          },
          {'theme': 'Postre','scores': {'Valentina': {'judge_1': 7, 'judge_2': 8, 'judge_3': 7},
                                        'Mateo': {'judge_1': 9, 'judge_2': 9, 'judge_3': 8},
                                        'Camila': {'judge_1': 8, 'judge_2': 7, 'judge_3': 9},
                                        'Santiago': {'judge_1': 7, 'judge_2': 7, 'judge_3': 6},
                                        'Lucía': {'judge_1': 9, 'judge_2': 9, 'judge_3': 9}
                                        }
          },
          {'theme': 'Cocina internacional', 'scores': {'Valentina': {'judge_1': 8, 'judge_2': 9, 'judge_3': 9},
                                                       'Mateo': {'judge_1': 7, 'judge_2': 6, 'judge_3': 7},
                                                       'Camila': {'judge_1': 9, 'judge_2': 8, 'judge_3': 8},
                                                       'Santiago': {'judge_1': 8, 'judge_2': 9, 'judge_3': 7},
                                                       'Lucía': {'judge_1': 7, 'judge_2': 7, 'judge_3': 8}
                                                       }
          },
          {'theme': 'Final libre', 'scores': {'Valentina': {'judge_1': 9, 'judge_2': 8, 'judge_3': 9},
                                              'Mateo': {'judge_1': 8, 'judge_2': 9, 'judge_3': 8},
                                              'Camila': {'judge_1': 7, 'judge_2': 7, 'judge_3': 7},
                                              'Santiago': {'judge_1': 9, 'judge_2': 9, 'judge_3': 9},
                                              'Lucía': {'judge_1': 8, 'judge_2': 8, 'judge_3': 7}
                                              }
          }
        ]



def main():

    chefs_data = initialize_chefs()
    chefs_data = process_data(chefs_data)
    display_final_results(chefs_data)



def initialize_chefs():
    """Initialize the general (empty) data for each chef."""
    chefs_data = {}

    for chef in rounds[0]["scores"].keys():
        chefs_data[chef] = {"total_score": 0, "rounds_won": 0, "best_round": 0, "average": None}

    return chefs_data



def process_data(chefs_data):
    """Process all the data, round by round."""
    for n_round, one_round in enumerate(rounds, start=1):

        # A list of dicts with name and score (from this round) of each chef
        chefs_this_round = []

        for name, scores in one_round["scores"].items():
            # Add scores from the three judges
            added_scores = sum(scores.values())
            # Update data from this round
            chefs_this_round.append({"name": name, "score": added_scores})
            # Update cumulative stats
            chefs_data[name]["total_score"] += added_scores
            if added_scores > chefs_data[name]["best_round"]:
                chefs_data[name]["best_round"] = added_scores

        # Sort the results from this round
        chefs_this_round.sort(key=lambda some_chef: some_chef["score"], reverse=True)

        # Credit the round win to the top scorer
        chefs_data[chefs_this_round[0]["name"]]["rounds_won"] += 1

        display_round_results(n_round, one_round, chefs_this_round)

    
    chefs_data = calculate_final_average(chefs_data)

    # Return sorted chefs by total score in descending order
    return dict(sorted(chefs_data.items(), key=lambda item : item[1]["total_score"], reverse=True))



def calculate_final_average(chefs_data):
    
    n_rounds = len(rounds)

    for chef, data in chefs_data.items():
        chefs_data[chef]["average"] = round((data["total_score"]/n_rounds), 1)

    return chefs_data



def display_round_results(n_round, one_round, chefs_this_round):
    print(f"\nRonda {n_round} - {one_round["theme"]}:")
    print(f"Ganador: {chefs_this_round[0]["name"]} ({chefs_this_round[0]["score"]} pts)")
    for pos, chef in enumerate(chefs_this_round[1:], start=2):
        print(f"{pos} lugar: {chef['name']} ({chef['score']} pts)")



def display_final_results(chefs_data):
    print("\n\nTabla de posiciones final:\n")
    print("Cocinero        Puntaje    Rondas ganadas    Mejor ronda    Promedio")
    print("-" * 68)
    for chef, data in chefs_data.items():
        print(f"{chef:<15} {data['total_score']:<10} {data['rounds_won']:<17} {data['best_round']:<14} {data['average']}")
    print("-" * 68)



if __name__ == "__main__":
    main()
